import fitz  # PyMuPDF
import os
import json

def extract_pdf_content(pdf_path):
    # Create output folder
    output_folder = "pdf_output"
    os.makedirs(output_folder, exist_ok=True)

    # Open PDF
    doc = fitz.open(pdf_path)
    output_data = {"pages": []}

    # Loop through pages
    for page_number in range(len(doc)):
        page = doc[page_number]
        text = page.get_text().strip()
        images = []

        # Extract images
        image_list = page.get_images(full=True)
        for img_index, img in enumerate(image_list, start=1):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            image_ext = base_image["ext"]
            image_filename = f"page{page_number+1}_image{img_index}.{image_ext}"
            image_path = os.path.join(output_folder, image_filename)

            # Save image
            with open(image_path, "wb") as img_file:
                img_file.write(image_bytes)
            images.append(image_filename)

        # Store text and image filenames
        output_data["pages"].append({
            "page_number": page_number + 1,
            "text": text,
            "images": images
        })

    # Save as JSON
    json_path = os.path.join(output_folder, "output.json")
    with open(json_path, "w", encoding="utf-8") as json_file:
        json.dump(output_data, json_file, indent=2)

    print(f"✅ Done! Extracted data saved to '{json_path}' and images saved in '{output_folder}/'")

# Run the function with your PDF
extract_pdf_content("IMO Grade 1 - 1-2.pdf")
